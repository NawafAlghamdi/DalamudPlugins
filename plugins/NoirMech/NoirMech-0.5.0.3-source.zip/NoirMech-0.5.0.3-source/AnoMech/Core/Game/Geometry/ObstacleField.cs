using System;
using System.Collections.Generic;
using System.Numerics;

namespace AnoMech.Core.Game.Geometry;

// A scenario's "geometry": the set of obstacles party bots steer around while
// moving. The special container that fully owns both the obstacle list and the
// steering algorithm — SimWorld just holds one instance and hands it to each
// party doppel; it has no obstacle logic of its own.
//
// Empty by default, so with no obstacles every bot moves in a straight line
// (Steer returns the desired direction unchanged). Scenarios mutate the field
// over their event timeline via Add / Remove / Clear; it is wiped on world
// teardown. Non-bot characters (bosses, the player) keep ObstacleField.Empty and
// are never affected.
//
// Steering is reactive and per-frame, not a planned path: it naturally copes
// with obstacles that appear, drift, or vanish mid-move, and is intentionally
// simple rather than globally optimal — good enough for sparse convex shapes,
// which is all this needs to be.
public sealed class ObstacleField
{
    // Shared empty field for every non-bot character. Never mutated: only
    // world.Obstacles is exposed to scenarios, so this stays pristine.
    public static readonly ObstacleField Empty = new();

    // How far ahead (local yalms) a bot looks to begin arcing around an obstacle. 4.5 covers a
    // full gap-to-gap span in Umad P1's 16-arrow ring (2y-radius obstacles 6y apart); Steer only
    // avoids what is inside this window.
    private const float LookAhead = 4.5f;

    // Depth (local yalms) over which a bot found *inside* an obstacle is pushed
    // back out. Only relevant when a bot ends up inside one (e.g. a circle that
    // spawns on top of it); normal grazing stays at the boundary with no push.
    private const float RecoveryBand = 1.0f;

    private readonly List<IObstacle> obstacles = new();

    public IReadOnlyList<IObstacle> All => obstacles;

    // Adds an obstacle and returns it (typed) so a scenario can keep the
    // reference for a later Remove, or to mutate it (e.g. a CircleObstacle's
    // Center/Radius) over time.
    public T Add<T>(T obstacle) where T : IObstacle
    {
        obstacles.Add(obstacle);
        return obstacle;
    }

    public void Remove(IObstacle obstacle) => obstacles.Remove(obstacle);

    public void Clear() => obstacles.Clear();

    // Projects `p` out onto the boundary of the obstacle it is most deeply inside
    // (or, with `margin` > 0, out to `margin` clear of it even if `p` was already
    // outside) so a destination authored -- or computed, e.g. a tether pull spot
    // that lands on/near an unrelated decorative obstacle -- becomes a reachable,
    // comfortably-clear point instead of an unreachable center the bot orbits
    // forever, or a boundary-grazing one Steer's tangent-glide can stall on.
    // Single-pass / single-obstacle: with overlapping obstacles the result may
    // still sit inside another (acceptable; best-effort by design).
    public Vector2 ClampOutside(Vector2 p, float margin = 0f)
    {
        if (Deepest(p, out var dist, out var normal) == null || dist >= margin) return p;
        return p - normal * (dist - margin);   // dist < margin, normal outward -> push out to margin clearance
    }

    // Nearest point to the projection `t0` on segment a->b (param clamped to
    // [tMin,tMax]) that is clear of every obstacle, found by scanning outward along
    // the line in both directions. Lets tether intercept stay ON the corridor when an
    // obstacle covers the nearest point: it slides to the closest open spot on the
    // line instead of being shoved perpendicular off it (which ClampOutside would do,
    // silently breaking the grab). Returns the projection unchanged when the field is
    // empty or no in-range point is clear (best-effort fallback).
    public Vector2 NearestClearOnSegment(Vector2 a, Vector2 b, float t0, float tMin, float tMax)
    {
        var seg = b - a;
        Vector2 At(float t) => a + seg * t;
        var len = seg.Length();
        if (obstacles.Count == 0 || len < 1e-6f || IsClear(At(t0))) return At(t0);

        var dt = 0.5f / len;   // probe in ~0.5-yalm steps along the line
        for (var d = dt; t0 - d >= tMin || t0 + d <= tMax; d += dt)
        {
            if (t0 + d <= tMax && IsClear(At(t0 + d))) return At(t0 + d);
            if (t0 - d >= tMin && IsClear(At(t0 - d))) return At(t0 - d);
        }
        return At(t0);
    }

    private bool IsClear(Vector2 p)
    {
        foreach (var o in obstacles)
            if (o.SignedDistance(p) < 0f) return false;
        return true;
    }

    // Returns the unit steering direction for a bot at `pos` heading in unit
    // `desired` toward a destination `dist` yalms away. With no obstacle in the way
    // this is just `desired` (=> straight line).
    //
    // If the straight line isn't clear, candidate headings are scanned outward from `desired`
    // (smallest deviation first, alternating sides) and the first whose whole look-ahead
    // segment clears every obstacle wins; a bot inside an obstacle biases the search outward
    // first. Gliding around the single nearest obstacle walked straight into the next one in a
    // dense field. Reactive per frame, not path planning.
    //
    // `side` (+1/-1, 0 = uncommitted) is the caller's per-mover memory of which way it turned:
    // once blocked, a bot keeps turning that way until the straight line clears. Picking the
    // smallest deviation afresh each frame let a bot tucked behind one arrow of a ring flip
    // between a left and a right heading forever without getting around it.
    internal Vector2 Steer(Vector2 pos, Vector2 desired, float dist, ref int side)
    {
        if (obstacles.Count == 0) return desired;

        // Look ahead along the path, but never past the destination — otherwise a bot settling
        // just outside an obstacle keeps probing LookAhead into it and gets deflected every
        // frame instead of arriving (the end-of-move twitch). On the final approach `reach`
        // shrinks to `dist`.
        var reach = MathF.Min(LookAhead, dist);

        var baseDir = desired;
        if (Deepest(pos, out var deepestDist, out var deepestNormal) != null && deepestDist < 0f)
        {
            var push = Math.Clamp(-deepestDist / RecoveryBand, 0f, 1f);
            var blended = desired + deepestNormal * push;
            if (blended.LengthSquared() > 1e-8f) baseDir = Vector2.Normalize(blended);
        }

        if (IsPathClear(pos, baseDir, reach))
        {
            side = 0;
            return baseDir;
        }

        if (side == 0)
        {
            for (var angleDeg = CandidateAngleStepDeg; angleDeg <= CandidateAngleMaxDeg; angleDeg += CandidateAngleStepDeg)
            {
                var angle = angleDeg * (MathF.PI / 180f);
                var left = Rotate(baseDir, angle);
                if (IsPathClear(pos, left, reach)) { side = 1; return left; }
                var right = Rotate(baseDir, -angle);
                if (IsPathClear(pos, right, reach)) { side = -1; return right; }
            }
            return baseDir;
        }

        // Boxed in on the committed side at full look-ahead (wedged between neighbouring
        // obstacles): keep edging that way on a short look-ahead rather than flipping sides.
        return FirstClearOnSide(pos, baseDir, side, reach)
            ?? FirstClearOnSide(pos, baseDir, side, MathF.Min(BoxedInLookAhead, reach))
            ?? baseDir;
    }

    private const float BoxedInLookAhead = 1f;

    private Vector2? FirstClearOnSide(Vector2 pos, Vector2 baseDir, int side, float reach)
    {
        for (var angleDeg = CandidateAngleStepDeg; angleDeg <= CandidateAngleMaxDeg; angleDeg += CandidateAngleStepDeg)
        {
            var heading = Rotate(baseDir, side * angleDeg * (MathF.PI / 180f));
            if (IsPathClear(pos, heading, reach)) return heading;
        }
        return null;
    }

    // 5 degrees resolves the ~19-degree gap between two arrows 6y apart at LookAhead range;
    // a 15-degree step could straddle it.
    private const float CandidateAngleStepDeg = 5f;
    private const float CandidateAngleMaxDeg = 175f;

    private static Vector2 Rotate(Vector2 v, float radians)
    {
        var cos = MathF.Cos(radians);
        var sin = MathF.Sin(radians);
        return new Vector2(v.X * cos - v.Y * sin, v.X * sin + v.Y * cos);
    }

    // Clearance beyond an obstacle's own radius, so a heading that grazes the exact boundary
    // doesn't clip after one movement step. Steer only; ClampOutside/NearestClearOnSegment keep
    // exact-boundary behaviour.
    private const float SteerMargin = 0.3f;

    // A Steer destination closer than SteerMargin to an obstacle never tests clear, so a bot
    // committed to a side would circle the obstacle forever on its final approach. Clamped a
    // hair past the margin so float error can't put it back inside.
    internal Vector2 ClampForSteering(Vector2 p) => ClampOutside(p, SteerMargin + 0.05f);

    private bool IsClearWithMargin(Vector2 p)
    {
        foreach (var o in obstacles)
            if (o.SignedDistance(p) < SteerMargin) return false;
        return true;
    }

    // Sampled in 0.5-yalm steps rather than a per-shape intersection test, so it works for any
    // IObstacle shape.
    private bool IsPathClear(Vector2 pos, Vector2 dir, float reach)
    {
        const float step = 0.5f;
        for (var d = step; d < reach; d += step)
            if (!IsClearWithMargin(pos + dir * d)) return false;
        return IsClearWithMargin(pos + dir * reach);
    }

    // The obstacle with the smallest signed distance from `p` (most inside, or
    // nearest if all are outside), with its outward normal at `p`.
    private IObstacle? Deepest(Vector2 p, out float dist, out Vector2 normal)
    {
        IObstacle? worst = null;
        dist = float.MaxValue;
        normal = default;
        foreach (var o in obstacles)
        {
            var d = o.SignedDistance(p);
            if (d < dist) { dist = d; worst = o; normal = o.Normal(p); }
        }
        return worst;
    }
}
